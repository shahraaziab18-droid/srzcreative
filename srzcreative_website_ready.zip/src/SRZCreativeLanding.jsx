
import React from 'react';
import { motion } from 'framer-motion';

export default function SRZCreativeLanding() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center p-6 bg-white rounded-xl shadow-lg max-w-xl"
      >
        <h1 className="text-3xl font-bold mb-4">SRZ Creative</h1>
        <p className="text-gray-700 mb-4">
          Architecture, Renders, Graphic Design & Portrait Sketches
        </p>
        <a href="mailto:hello@srzcreative.com" className="inline-block px-4 py-2 rounded-md bg-indigo-600 text-white">
          Contact Me
        </a>
      </motion.div>
    </div>
  );
}
